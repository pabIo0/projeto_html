- Falta só arrumar um jeito de centralizar os botões no menu quando o site fica responsivo
- arrumar tamanho do body (acho que é alguma coisa no main ou no .produto)
- opcional: adicionar uma imagem para usar de background
- perguntar sobre uso de letra maiuscula no html
Quem somos:
- Fazer com que o footer fique no final da pagina

_____________________________________________________________________

AVALIAÇÃO
2 páginas
Cabeçalho
Rodapé
Mínimo 2 colunas
Ser responsivo
  
| Critérios                                | Pontuação |
|------------------------------------------|-----------|
| 1) Descrição dos Casos de Uso            | 10 pontos |
| 2) Páginas HTML + CSS                    | 10 pontos |
| 3) Responsividade                        | 10 pontos |