- Deixar o site responsivo
- Ajustar a posição no header
- Ajustar a logo no Header
- otimizar o css - redundante
- criar um botão de "Adicionar ao carrinho"
- arrumar tamanho do body (acho que é alguma coisa no main ou no .produto)
- adicionar uma imagem para usar de background
- ajustar o espaçamento das fontes
- perguntar sobre uso de letra maiuscula no html
- sobre a borda preta nas palavras do header
- dividir o botao e o texto do botao

_____________________________________________________________________

AVALIAÇÃO
2 páginas
Cabeçalho
Rodapé
Mínimo 2 colunas
Ser responsivo
  
| Critérios                                | Pontuação |
|------------------------------------------|-----------|
| 1) Descrição dos Casos de Uso            | 10 pontos |
| 2) Páginas HTML + CSS                    | 10 pontos |
| 3) Responsividade                        | 10 pontos |