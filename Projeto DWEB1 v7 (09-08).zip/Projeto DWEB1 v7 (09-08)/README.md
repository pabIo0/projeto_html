Participantes:
Pablo Ladeira
Gabriel Riguete Carneiro

Link figma: https://www.figma.com/file/pDYIA1hHC7DDmX1XArvjZP/Oktoplus-Shop-Website?type=design&node-id=0-1&mode=design
